<?php /* Template Name: Contact Page */ ?>

<?php get_header() ?>

<?php get_template_part('components/page-header'); ?>

<?php get_template_part('components/contact-content'); ?>

<?php get_template_part('components/page-footer'); ?>

<?php get_footer() ?>
