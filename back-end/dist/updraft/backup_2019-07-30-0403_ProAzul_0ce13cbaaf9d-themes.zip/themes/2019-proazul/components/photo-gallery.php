<div class="photo-gallery">
    <h2 class="photo-gallery-title">Galeria de Photos</h2>
    <div class="photo-gallery-container">
        <?php echo do_shortcode('[metaslider title="' . get_field('galeria_de_fotos') . '"]'); ?>
    </div>
</div>
