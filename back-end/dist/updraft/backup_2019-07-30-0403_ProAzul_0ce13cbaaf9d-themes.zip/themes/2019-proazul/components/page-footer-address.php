<section class="footer-address container-fluid text-center">
    <p><?php echo $GLOBALS['cgv']['rodape'] ?></p>
</section>
