<div class="search-form">
    <form class="form-inline" role="search" method="get" id="searchform" action="/">
        <input class="form-control w-100" type="search" placeholder="Buscar" aria-label="Buscar" name="s" id="s">
        <button class="btn" type="submit" id="searchsubmit" value="Search">Buscar</button>
    </form>
</div>            
