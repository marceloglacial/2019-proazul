<?php /* Template Name: Home Page */ ?>
<?php get_header() ?>

<?php get_template_part('components/page-header'); ?>

<?php get_template_part('components/home-hero'); ?>

<?php get_template_part('components/home-content'); ?>

<?php get_template_part('components/page-footer'); ?>

<?php get_footer() ?>
