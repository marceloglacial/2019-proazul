import SweetModal from './components/SweetModal'
import SweetModalTab from './components/SweetModalTab'

export {
	SweetModal,
	SweetModalTab
}
